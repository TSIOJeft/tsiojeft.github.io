# 主页

> 你一直需要的一个清理 APP ，一个简洁的清理工具。
# 官方下载地址
[酷安](https://www.coolapk.com/apk/com.farplace.qingzhuo) [小米](http://app.mi.com/details?id=com.farplace.qingzhuo)
[魅族](http://app.meizu.com/apps/public/detail?package_name=com.farplace.qingzhuo) [应用宝](https://sj.qq.com/myapp/detail.htm?apkName=com.farplace.qingzhuo)

# 最新版本 1.5.7

## 更新日志

```text
优化规则添加 APP icon 丢失问题
优化重复文件卡住问题
优化清理运存部分用户无法使用的问题
新增根目录整理 强迫症清理 文件大小分析 文件夹快速操作菜单
优化高级版用户高级功能时而不能使用的问题
优化高级版支付的问题

```